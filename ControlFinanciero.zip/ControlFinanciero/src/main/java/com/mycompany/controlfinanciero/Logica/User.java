
package com.mycompany.controlfinanciero.Logica;


public class User {
    private int id;
    private String nombreBarbero;
    private String contrasena;
    private String correo;
    private String rol;
    
    
    public User(int id, String nombreBarbero, String contrasena, String correo, String rol){
        
        this.id = id;
        this.nombreBarbero = nombreBarbero;
        this.correo = correo;
        this.rol = rol;
        
        
    }
    
    
}
