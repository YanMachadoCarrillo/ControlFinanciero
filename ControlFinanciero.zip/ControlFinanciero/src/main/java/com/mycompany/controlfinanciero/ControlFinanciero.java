

package com.mycompany.controlfinanciero;


import com.mycompany.controlfinanciero.Igu.Inicio;






public class ControlFinanciero {

    public static void main(String[] args) {
     
       Inicio inicio = new Inicio();
        
        inicio.setVisible(true);
        
        
        
        
    }
}
